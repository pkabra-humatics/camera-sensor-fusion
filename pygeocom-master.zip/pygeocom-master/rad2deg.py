import math

def rad2deg(radians):
    totalSeconds = int(round(radians * 180 * 3600 / (math.pi)))
    seconds = totalSeconds % 60
    minutes = int(math.floor(totalSeconds / 60))%60
    degrees = int(math.floor(totalSeconds / 3600))
    return (degrees,minutes,seconds)

rad2deg(math.pi/2)
