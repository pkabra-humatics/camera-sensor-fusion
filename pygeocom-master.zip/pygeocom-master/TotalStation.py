import serial
from pygeocom import PyGeoCom, RecordFormat, ControllerMode, ControllerStopMode, LockInStatus, PrismType, ReflectorType, MeasurementMode, MeasurementProgram, TargetType, PositionMode, ATRRecognitionMode, OnOff, TMCInclinationMode, TMCMeasurementMode
from datetime import datetime
from time import sleep, time
import numpy as np

class TotalStation:
    def __init__(self, device='/dev/ttyUSB0', baud = 19200, timeout = 180):
        """
            Device: Serial port of the USB device, often /dev/ttyUSB0
        """
        self.device = device
        self.baud = baud
        self.timeout = timeout

        # Open Serial Device
        self.ser = serial.Serial(self.device, self.baud, timeout=self.timeout)
        self.geo = PyGeoCom(self.ser, debug=False)

        # Initialize
        motor_lock_status = self.geo.get_motor_lock_status()
        if motor_lock_status == LockInStatus.LOCKED_IN:
             self.geo.stop_controller(ControllerStopMode.NORMAL)
        self.geo.start_controller(ControllerMode.RELATIVE_POSITIONING)
        self.geo.set_measurement_program(MeasurementProgram.CONT_REF_STANDARD)

        self.geo.set_target_type(TargetType.REFLECTOR)
        self.geo.set_prism_type(PrismType.LEICA_360)
        self.geo.set_search_spiral(3.14, 0.2)
        self.geo.search_target()

        self.geo.user_lock_state_on()
        self.geo.lock_in() 

        self.geo.do_measure(TMCMeasurementMode.DISTANCE_TRACKING, TMCInclinationMode.AUTOMATIC)

    def measure(self):
        coordinate, measure_time, coordinate_cont, measure_time_cont = self.geo.get_coordinate(TMCInclinationMode.AUTOMATIC)
        return np.array([ coordinate.east, coordinate.north, coordinate.head ])

    def __exit__(self):
        self.geo.user_lock_state_off()
        self.ser.close()

if __name__ == "__main__":
    ts = TotalStation()

    print(ts.measure())
