import serial
from pygeocom import PyGeoCom, RecordFormat, ControllerMode, ControllerStopMode, LockInStatus, PrismType, ReflectorType, MeasurementMode, MeasurementProgram, TargetType, PositionMode, ATRRecognitionMode, OnOff, TMCInclinationMode, TMCMeasurementMode
from time import sleep, time

# run $ ls /dev
ser = serial.Serial("/dev/ttyUSB0", 19200, timeout=10)
print("Initialized Serial")
geo = PyGeoCom(ser, debug=False)
print("Initialized PyGeoCom")

motor_lock_status = geo.get_motor_lock_status()
print(motor_lock_status)

if motor_lock_status == LockInStatus.LOCKED_IN:
    print("Stopping Controller")
    geo.stop_controller(ControllerStopMode.NORMAL)

geo.start_controller(ControllerMode.RELATIVE_POSITIONING)



# Print the current position
angles = geo.get_angles_simple(TMCInclinationMode.AUTOMATIC)
print(angles)