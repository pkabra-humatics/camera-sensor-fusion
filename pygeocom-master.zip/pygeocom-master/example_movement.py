import serial
from pygeocom import PyGeoCom, RecordFormat, ControllerMode, ControllerStopMode, LockInStatus, PrismType, ReflectorType, MeasurementMode, MeasurementProgram, TargetType, PositionMode, ATRRecognitionMode, OnOff, TMCInclinationMode, TMCMeasurementMode
from time import sleep, time

# run $ ls /dev
ser = serial.Serial("/dev/ttyUSB0", 19200, timeout=10)
print("Initialized Serial")
geo = PyGeoCom(ser, debug=False)
print("Initialized PyGeoCom")
#sleep(3)

motor_lock_status = geo.get_motor_lock_status()
print(motor_lock_status)
#sleep(3)
if motor_lock_status == LockInStatus.LOCKED_IN:
    print("Stopping Controller")
    geo.stop_controller(ControllerStopMode.NORMAL)
#    sleep(3)
geo.start_controller(ControllerMode.RELATIVE_POSITIONING)
#sleep(3)


# Print the current position
angles = geo.get_angles_simple(TMCInclinationMode.AUTOMATIC)
#sleep(3)
print(angles)

#for i in range(60):
#
#    angles_prev = geo.get_angles_simple(TMCInclinationMode.AUTOMATIC)
#    angles_new = copy.deepcopy(angles_prev)
##    angles_new.hz = angles_0.hz
##    angles_new.v = angles_prev.v-0.000290888
#    # Move total station to the current
#    geo.position(angles_new.hz, angles_new.v)
#    angles_new_meas = geo.get_angles_simple(TMCInclinationMode.AUTOMATIC)
#    #sleep(3)
#    print(angles_new_meas.v - angles_prev.v)


error_avg = 0
for i in range(12):
    # 5 min = 0.0015029223920 rad
    # 1 deg = 0.0174533 rad
    geo.position(angles.hz, angles.v+0.0015029223920)
    print(angles.hz, angles.v+0.0015029223920)
    command = angles.v+0.0015029223920
    angles = geo.get_angles_simple(TMCInclinationMode.AUTOMATIC)
    print(angles)
    result = angles.v
    error = abs(command-result)
    print(error)
    error_avg+=error/12

    print('--------------')
print(error_avg)
## Move total station to the current
#geo.position(angles.hz, angles.v-0.000290888)
#result = geo.get_angles_simple(TMCInclinationMode.AUTOMATIC)
##sleep(3)
#print(result)