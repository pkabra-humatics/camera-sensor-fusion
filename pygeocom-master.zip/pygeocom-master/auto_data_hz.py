# led at right: (4.143881225967472, 1.6789268392)
# led at left: (5.136408544754107, 1.6789268392)
# led at center: (4.64014488536, 1.6789268392)

import RPi.GPIO as GPIO
import time
import os
import serial
from pygeocom import PyGeoCom, RecordFormat, ControllerMode, ControllerStopMode, LockInStatus, PrismType, ReflectorType, MeasurementMode, MeasurementProgram, TargetType, PositionMode, ATRRecognitionMode, OnOff, TMCInclinationMode, TMCMeasurementMode
from time import sleep, time
import math

def rad2deg(radians):
    totalSeconds = int(round(radians * 180 * 3600 / (math.pi)))
    seconds = totalSeconds % 60
    minutes = int(math.floor(totalSeconds / 60))%60
    degrees = int(math.floor(totalSeconds / 3600))
    return (degrees,minutes,seconds)


GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(26,GPIO.OUT)

ser = serial.Serial("/dev/ttyUSB0", 19200, timeout=10)
print("Initialized Serial")
geo = PyGeoCom(ser, debug=False)
print("Initialized PyGeoCom")
motor_lock_status = geo.get_motor_lock_status()
print(motor_lock_status)

if motor_lock_status == LockInStatus.LOCKED_IN:
    print("Stopping Controller")
    geo.stop_controller(ControllerStopMode.NORMAL)
geo.start_controller(ControllerMode.RELATIVE_POSITIONING)

# set init, led at right
geo.position(4.143881225967472, 1.6789268392)

# Print the current position
angle_init = geo.get_angles_simple(TMCInclinationMode.AUTOMATIC)
print(angle_init)
error_avg = 0
delta = 0.0014544410433

counts = 683
for i in range(counts):

    # 5 min = 0.0014544410433 rad : 683 counts

    geo.position(angle_init.hz + i*delta, angle_init.v)
    
    print('target: ',angle_init.hz + i*delta, angle_init.v)
    target = angle_init.hz + i*delta
    
    angle_curr = geo.get_angles_simple(TMCInclinationMode.AUTOMATIC)
    print('achieved: ',angle_curr)
    achieved = angle_curr.hz
    
    error = abs(target - achieved)
    print('error= ',rad2deg(error))
    
    error_avg+=error/counts
    
  
    degrees,minutes,seconds = rad2deg(i*delta)
    print(degrees,minutes,seconds)
    
    GPIO.output(26,GPIO.HIGH)
    print("LED on")
    filename = "/home/pi/Videos/videos_hz_5min/video_on_ss1_hz_{0}_{1}_{2}.h264".format(degrees,minutes,seconds)
    cmd = "raspivid -ss 1 -o " + filename + " -t 5000"
    os.system(cmd)

    GPIO.output(26,GPIO.LOW)
    print("LED off")
    filename = "/home/pi/Videos/videos_hz_5min/video_off_ss1_hz_{0}_{1}_{2}.h264".format(degrees,minutes,seconds)
    cmd = "raspivid -ss 1 -o " + filename + " -t 5000"
    os.system(cmd)
    print('-------------------------------------------------------------')  
print('Avg error= ',rad2deg(error_avg))